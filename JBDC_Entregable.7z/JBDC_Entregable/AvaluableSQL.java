package JBDC_Entregable;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class AvaluableSQL {
	/**
	 * 
	 * @author Joaquin Peris Gonzalez
	 *
	 *
	 *         Este Array list la funcion que hace es que va leyendo el archivo
	 *         linia a linia y te los separa por sus identificadores para luego
	 *         crear un objeto donde se guardan los libros para luego subirlo a atu
	 *         base de datos.
	 */
	public static ArrayList<Libros> leyendo(String ruta) {

		ArrayList<Libros> libros = new ArrayList<Libros>();

		try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
			String linia;
			int cont = 0;
			while ((linia = br.readLine()) != null) {
				if (cont >= 1) {
					String[] datos = linia.split(";");
					Libros datoslibros = new Libros();

					for (int i = 1; i < datos.length; i++) {
						if (datos[i].equals("")) {
							datos[i] = "No consta nada sobre ellos";
						}
					}

					datoslibros.setTitol(datos[0]);
					datoslibros.setAutor(datos[1]);
					datoslibros.setAnyNaiximent(datos[2]);
					datoslibros.setAnyPublicacio(datos[3]);
					datoslibros.setEditorial(datos[4]);
					datoslibros.setNombrePagines(datos[5]);

					libros.add(datoslibros);
				}
				cont++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return libros;
	}

	/**
	 * 
	 * @author Joaquin Peris Gonzalez
	 *
	 *
	 *         En este metodo la funcion que hace es coger los datos que lees de tu
	 *         archivo y haces la conexion con la base de datos para poder subir los
	 *         datos que has leido y los tienes en el array list anterior los lees y
	 *         los introducces en strings para que luego se suba a tu base de datos.
	 */
	public static void main(String[] args) {

		ArrayList<Libros> libretes = leyendo(".\\src\\JBDC_Entregable\\Archivos\\AE04_T1_4_JDBC_Dades.csv");

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/libreria", "root", "");
			Statement stmt = con.createStatement();

			for (int i = 1; i < libretes.size(); i++) {

				String titulo = libretes.get(i).getTitol();
				String autor = libretes.get(i).getAutor();
				String anyNaiximent = libretes.get(i).getAnyNaiximent();
				String anyPublicacio = libretes.get(i).getAnyPublicacio();
				String editorial = libretes.get(i).getEditorial();
				String nombrePagines = libretes.get(i).getNombrePagines();

				PreparedStatement ps = con.prepareStatement(
						"INSERT INTO libres (titulo, autor, anyonacimiento, anyopublicacion, editorial,numpaginas) VALUES (?,?,?,?,?,?)");
				ps.setString(1, titulo);
				ps.setString(2, autor);
				ps.setString(3, anyNaiximent);
				ps.setString(4, anyPublicacio);
				ps.setString(5, editorial);
				ps.setString(6, nombrePagines);

				ps.executeUpdate();
				ps.close();
			}
			/**
			 * 
			 * @author Joaquin Peris Gonzalez
			 *
			 *
			 *         Aqui son dos funcionalidades que selecciona unos determinados datos
			 *         que te pidan.
			 */
			ResultSet rs = stmt
					.executeQuery(("SELECT titulo, autor, anyopublicacion FROM libres WHERE anyonacimiento < 1950"));
			while (rs.next()) {
				System.out.println(rs.getString(1) + " " + rs.getString(2) + " " + rs.getString(3));
			}

			rs = stmt.executeQuery(("SELECT editorial FROM libres WHERE anyopublicacion >= 2001"));
			while (rs.next()) {
				System.out.println(rs.getString(1));
			}

			stmt.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
