package JBDC_Entregable;

/**
 * 
 * @author Joaquin Peris Gonzalez
 *
 *
 *         Esta es la clase Libros
 *
 * @Atributos titol autor anyNaiximent anyPublicacio editorial nombrePagines
 *
 *            En esta calse estan los getters and setters
 */
public class Libros {
	private String titol;
	private String autor;
	private String anyNaiximent;
	private String anyPublicacio;
	private String editorial;
	private String nombrePagines;

	public String getTitol() {
		return titol;
	}

	public void setTitol(String titol) {
		this.titol = titol;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getAnyNaiximent() {
		return anyNaiximent;
	}

	public void setAnyNaiximent(String anyNaiximent) {
		this.anyNaiximent = anyNaiximent;
	}

	public String getAnyPublicacio() {
		return anyPublicacio;
	}

	public void setAnyPublicacio(String anyPublicacio) {
		this.anyPublicacio = anyPublicacio;
	}

	public String getEditorial() {
		return editorial;
	}

	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}

	public String getNombrePagines() {
		return nombrePagines;
	}

	public void setNombrePagines(String nombrePagines) {
		this.nombrePagines = nombrePagines;
	}

}
