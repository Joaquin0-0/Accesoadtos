-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-11-2021 a las 13:36:33
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `libreria`
--
CREATE DATABASE IF NOT EXISTS `libreria` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `libreria`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libres`
--

CREATE TABLE `libres` (
  `titulo` varchar(100) NOT NULL,
  `autor` varchar(1000) NOT NULL,
  `anyonacimiento` varchar(50) NOT NULL,
  `anyopublicacion` varchar(50) NOT NULL,
  `editorial` varchar(100) NOT NULL,
  `numpaginas` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `libres`
--

INSERT INTO `libres` (`titulo`, `autor`, `anyonacimiento`, `anyopublicacion`, `editorial`, `numpaginas`) VALUES
('El juego de Ender', 'Orson Scott Card', '1951', '1977', 'Ediciones B', '509'),
('Lazarillo de Tormes', 'Anónimo', 'No consta', '1554', 'Clásicos Populares', '150'),
('Las uvas de la ira', 'John Steinbeck', '1902', '1939', 'Alianza', '619'),
('Watchmen', 'Alan Moore', '1953', '1980', 'ECC', '416'),
('La hoguera de las vanidades', 'Tom Wolfe', '1930', '1980', 'Anagrama', '636'),
('La familia de Pascual Duarte', 'Camilo José Cela', '1916', '1942', 'Destino', '165'),
('El señor de las moscas', 'William Golding', '1911', '1972', 'Alianza', '236'),
('La ciudad de los prodigios', 'Eduardo Mendoza', '1943', '1986', 'Seix Barral', '541'),
('Ensayo sobre la ceguera', 'José Saramago', '1922', '1995', 'Santillana', '439'),
('Los surcos del azar', 'Paco Roca', '1969', '2013', 'Astiberri', '349'),
('Ghosts of Spain', 'Giles Tremlett', '1962', '2006', 'Faber & Faber', '468'),
('Sidi', 'Arturo Pérez Reverte', '1951', '2019', 'Penguin', '369'),
('Dune', 'Frank Herbert', '1920', '1965', 'Acervo', '741');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
