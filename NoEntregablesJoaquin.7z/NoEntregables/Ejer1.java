package NoEntregables;

public class Ejer1 {

	public static void main(String[] args) {

		int x = 9;
		int y = 1;

		int suma = x + y;
		
		System.out.println("El resultado es  " + suma);
	}

}
