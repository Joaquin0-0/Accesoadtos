package NoEntregables;

import java.util.Scanner;

public class Ejer3 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int x;
		int y;
		x = sc.nextInt();
		y = sc.nextInt();
		int suma = x + y;

		System.out.println("El resultado es  " + suma);
	}

}
