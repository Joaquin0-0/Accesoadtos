package NoEntregables;

import java.util.Scanner;

public class Ejer9 {

	public static void main(String[] args) {
int x;
Scanner sc = new Scanner(System.in);
		System.out.println("Elige un numero entre 1y 12");
		x = sc.nextInt();
	}

}
