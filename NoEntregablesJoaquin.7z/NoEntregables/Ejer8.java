package NoEntregables;

import java.util.Scanner;

public class Ejer8 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int x;
		
		System.out.println("Elige un numero entre 1y 12");
		x = sc.nextInt();

		if (x == 1) {
			System.out.println("Enero");
		} else if (x == 2) {
			System.out.println("Febrero");
		}
		if (x == 3) {
			System.out.println("Marzo");
		} else if (x == 4) {
			System.out.println("Abril");
		}
		if (x == 5) {
			System.out.println("Mayo");
		} else if (x == 6) {
			System.out.println("Junio");
		}
		if (x == 7) {
			System.out.println("Julio");
		} else if (x == 8) {
			System.out.println("Agosto");
		}
		if (x == 9) {
			System.out.println("Septiembre");
		} else if (x == 10) {
			System.out.println("Octubre");
		}
		if (x == 11) {
			System.out.println("Noviembre");
		} else if (x == 12) {
			System.out.println("Diciembre");
		}
	}

}
