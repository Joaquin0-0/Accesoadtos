package NoEntregables;

import java.util.Iterator;
import java.util.Scanner;

public class Ejer11 {

	public static void main(String[] args) {
		char[] letras = { 'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H',
				'L', 'C', 'K', 'E', 'T' };
		int calculetra;
		Scanner sc = new Scanner(System.in);

		int dni;
		System.out.println("Dime tu dni");
		dni = sc.nextInt();

		calculetra = dni % 23;
		

for (int i = 0; i < letras.length; i++) {
	if (calculetra==i) {
		System.out.println("La letra de tu dni es " + letras[i]);
		
	}
}
	}

}
