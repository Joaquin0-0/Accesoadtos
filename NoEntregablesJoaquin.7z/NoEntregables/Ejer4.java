package NoEntregables;

import java.util.Scanner;

public class Ejer4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int x;
		int y;
		x = sc.nextInt();
		y = sc.nextInt();
	
		if (x>y) {
			System.out.println("El primer numero" + x + "que el segundo " + y );
			System.out.println("El primer numero" + y + "que el segundo " + x );
		}else {
			System.out.println("El primer numero" + y + "que el segundo " + x );
			System.out.println("El primer numero" + x + "que el segundo " + y );
		}

		if (x==y) {
			System.out.println("Son iguales");
			
		}
		
	}

}
