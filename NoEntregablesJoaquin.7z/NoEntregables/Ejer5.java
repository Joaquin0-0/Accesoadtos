package NoEntregables;

import java.util.Scanner;

public class Ejer5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x;
		int y;
		x = sc.nextInt();
		y = sc.nextInt();
		do {

		} while (x == y);

	}
	
}
