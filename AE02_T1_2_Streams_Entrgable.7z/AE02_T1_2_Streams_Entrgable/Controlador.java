package AE02_T1_2_Streams_Entrgable;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.text.Caret;

public class Controlador {

	private Modelo modelo;
	private Vista vista;
	private ActionListener actionListenerBuscar, actionListenerReemplazar;
	private String ficheroLectura, ficheroEscritura;
	private String textoBuscar, textoReemplazar;

	public Controlador(Vista vista, Modelo modelo) {
		this.vista = vista;
		this.modelo = modelo;
		mostrar();
	}


	public void mostrar() {
		
		ArrayList<String> buscar =modelo.contenidoFichero(modelo.getFichero_lectura());
		
		for (int i = 0; i < buscar.size(); i++) {
			
			vista.getTextAreaOriginal().append(buscar.get(i)+ "\n");
			
		}
		vista.getBtnBuscar().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String buscadas = vista.getTextFieldBuscar().getText();

				int num= modelo.buscarT(buscadas);
				vista.getTextAreaModificado().setText(""+num);		}
		});

		vista.getBtnReemplazar().addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				String buscadas = vista.getTextFieldBuscar().getText();
				String rempla = vista.getTextFieldReemplazar().getText();
				String cam = vista.getTextAreaOriginal().getText();
				
				String chmod = modelo.remplazar(rempla,cam,buscadas);
				
				vista.getTextAreaModificado().setText(""+chmod);
			}
		});
	}
	}

