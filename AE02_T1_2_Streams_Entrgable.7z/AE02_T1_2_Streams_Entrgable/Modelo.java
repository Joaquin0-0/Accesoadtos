package AE02_T1_2_Streams_Entrgable;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Modelo {
	private String fichero_lectura;
	private String fichero_escritura;
	private Modelo modelo;
	private Vista vista;

	public Modelo() {
		fichero_lectura = "C:\\eclipse-workspace\\Accesde\\src\\AE02_T1_2_Streams_Entrgable\\AE02_T1_2_Streams_Groucho.txt";
		fichero_escritura = "C:\\eclipse-workspace\\Accesde\\src\\AE02_T1_2_Streams_Entrgable\\Goucho.txt";
	}

	public String ficheroLectura() {
		return fichero_escritura;
	}

	public String ficheroEscritura() {
		return fichero_escritura;
	}

	public String getFichero_lectura() {
		return fichero_lectura;
	}

	public void setFichero_lectura(String fichero_lectura) {
		this.fichero_lectura = fichero_lectura;
	}

	public String getFichero_escritura() {
		return fichero_escritura;
	}

	public void setFichero_escritura(String fichero_escritura) {
		this.fichero_escritura = fichero_escritura;
	}

	public ArrayList<String> contenidoFichero(String fichero) {
		String fichero2 = "";
		FileReader xivo;
		ArrayList<String> texto = new ArrayList();

		

		try {
			xivo = new FileReader(fichero);
			BufferedReader br = new BufferedReader(xivo);
			while ((fichero2 = br.readLine()) != null) {
				texto.add(fichero2);
			}

			br.close();
		} catch (Exception e) {

		}
		return texto;
	}

	public int buscarT(String txt) {
		ArrayList<String> buscar = new ArrayList(contenidoFichero(getFichero_lectura()));

		int contador = 0;

		for (int i = 0; i < buscar.size(); i++) {
			int posicion = buscar.get(i).indexOf(txt);
			if (posicion >= 0) {
				contador++;

			}
			while (buscar.get(i).indexOf(txt, posicion++) + 1 != 0) {
				contador++;
				posicion = buscar.get(i).indexOf(txt, posicion++) + 1;
			}
		}
		return contador;
	}

	public String remplazar(String texto, String cambiar,String changed) {
		
		
	String	texto2 = cambiar.replaceAll(changed, texto);

		try {
			String ruta= fichero_escritura;
			File file = new File(ruta);
			
			if (!file.exists()) {
				file.createNewFile();				
			}
			FileWriter fw = new FileWriter(file);
			BufferedWriter bw = new  BufferedWriter(fw);
			bw.write(texto2);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return texto2;

	}
}
